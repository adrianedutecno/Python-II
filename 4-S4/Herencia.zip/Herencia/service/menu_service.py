#los nombres de las clases con mas de una palabra van en UpperCamelCase
class MenuService: #la funcion de esta clase es llevar todos los metodos que se realizan para el menu
    def imprimir_menu(self):
        print('Bievenido al sistema:')
        print('1. Crear Cliente')
        print('2. Crear Supervisor')
        print('3. Salir')
    